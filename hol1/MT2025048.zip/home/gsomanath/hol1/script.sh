#!/bin/bash

echo "Script executed at $(date)" >> /home/gsomanath/hol1/daemon_log.txt

